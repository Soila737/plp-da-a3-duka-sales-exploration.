# Duka Electronics H1 Sales Exploration

## Project Overview
This project explores 1,000 Duka Electronics sales orders generated for the first half of 2026 using random seed 2026.

## Questions Answered
- How does revenue and order count vary by branch?
- Which products generate the most revenue and units sold?
- How do weekday and weekend sales compare?
- Which month has the highest and lowest revenue?
- Which Premium online orders came from Nairobi and Mombasa?

## Executive Summary
- Duka Electronics recorded **1,000 orders** across **5 branches** during the first half of 2026.
- Nairobi ranked first, generating **KES 26,106,100** from **376 orders**.
- Laptops generated the highest product revenue at **KES 41,535,000**, while tablets led unit sales with **691 units**.
- Weekdays generated **KES 51,856,200** from **723 orders**, compared with **KES 19,936,300** from **277 weekend orders**.
- April was the best month at **KES 13,518,300**, while **83** Premium online orders from Nairobi and Mombasa generated **KES 10,218,000**.

## Project Files
- `generate_data.py`: Generates the reproducible source data.
- `duka_sales.csv`: Generated source data.
- `duka_sales_exploration.ipynb`: Analysis and answers.
- `outputs/premium_online_coast_capital.csv`: Filtered orders.
- `excel/duka_branch_summary.xlsx`: Excel workbook.
- `requirements.txt`: Required Python libraries.

## How to Run
1. Install libraries: `pip install -r requirements.txt`.
2. Run `python generate_data.py`.
3. Open `duka_sales_exploration.ipynb` in Jupyter or Google Colab.
4. Run all notebook cells from top to bottom.
5. In Excel, create the native PivotTable required by the assignment.
